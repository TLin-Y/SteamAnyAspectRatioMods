Final Fantasy Resonance - Ultrawide (32:9 / 24:10 / 21:9, 16:10) 2.6.3
======================================================================

IMPORTANT when updating: the settings file moved to refilomod\ultrawide\FFRS_UW.ini (see INSTALL).
The ini is now divided into sections ([General], [Hud], [Field], [Battle],
[Menu], [Map], [Cutscene], [Graphics]). Old inis are still read, but only the
new file contains all options and comments. Copy over your own values if you
changed any.

Menus, HUD and the result screens are moved directly in the game instead of
being corrected while they are drawn, so they sit in the right place from the
first frame. Please report anything that does not look right.

Removes the 16:9 limit: true ultrawide image (Hor+), the menus move into the
centered 16:9 area, the title screen stays clean, story cutscenes play in
their original 16:9 (black bars), and the resolution list offers your
monitor's real resolutions. The HUD (battle and field) can sit inside the
centered 16:9 area or at the screen edges, per element if you like.

HUD LAYOUT
 The battle HUD (turn order, enemy info, command menu, party status) and the
 field HUD (current quest, minimap, region info) are
 placed inside the centered 16:9 area by default (HudLayout=original). With
 HudLayout=wide they stay at the screen edges. Every element can be set on
 its own in FFRS_UW.ini. On displays wider than 16:9 the in-game menu (F2) has a
 position slider (0-100 %) for every HUD element and one for all of them: 0 % = inside
 the centred 16:9 area, 100 % = at the screen edge, anything in between puts it
 in between. In the ini the same values are HudSpread and the per-element keys
 (a number from 0 to 100, or original / wide). Changes to these HUD settings are picked up
 automatically within a second while the game is running (just save the
 ini); the settings in [Map] are applied live as well. All other ini
 settings apply after a restart.

TESTED ON
 Xbox app / Microsoft Store full version and Steam full version: tested by
 the author with this version.
 Resolutions tested: 5120x1440 and 3440x1440 in the final pass; earlier
 versions were also tested at 3840x1080 and 3456x1440 (24:10).

SUPPORTED ASPECT RATIOS
 The layout (menus, title screen, cutscene bars, centered 16:9 area) is
 calculated from your real resolution, with separate rule sets for 32:9 and
 wider, for about 24:10 (e.g. 3456x1440, 3840x1600) and for about 21:9. It is
 active for ultrawide ratios of about 21:9 and wider (width at least 1.9 x
 height). Each ratio has its own complete rule set, so a fix for one never affects another. All three were tested.
 Screens that are taller than 16:9 (16:10, e.g. 1920x1200 or 2560x1600): the
 game camera shows more of the world above and below instead of zooming in
 (Vert+), cutscenes and videos keep their original 16:9. Menus and HUD are
 scaled by the game itself and need no shifting. The flame border of the
 battle bonus phase is moved to the bottom edge. Tested at a custom 1920x1200
 resolution. Narrower ratios (4:3, 5:4) are untested.

INSTALL
 The zip contains winmm.dll and the folder refilomod (core + ultrawide module
 with FFRS_UW.ini), plus this README.
 Copy winmm.dll and the whole refilomod folder (keep the folder structure) into
 the folder that contains the game's .exe:

 Steam:
  <Steam library>\steamapps\common\FINAL FANTASY RESONANCE\FFRS\Binaries\Win64\
  (the folder with FFRS-Win64-Shipping.exe)

 Xbox app / Microsoft Store (PC):
  <install folder>\FINAL FANTASY RESONANCE\Content\FFRS\Binaries\WinGDK\
  e.g. C:\XboxGames\FINAL FANTASY RESONANCE\Content\FFRS\Binaries\WinGDK\
  (the folder with FFRS-WinGDK-Shipping.exe)

 Result:
  <exe folder>\winmm.dll
  <exe folder>\refilomod\core\core_002_004.dll
  <exe folder>\refilomod\ultrawide\ultrawide.dll
  <exe folder>\refilomod\ultrawide\FFRS_UW.ini

 The demo uses the same folders inside "FINAL FANTASY RESONANCE DEMO".
 The same files work for both versions.
 Then start the game, open Settings > Graphics and pick your ultrawide
 resolution in Fullscreen. Windowed/Borderless use the game's own list.

 UPDATING from 2.3.5 or older (core_002_002.dll): delete the old core files in
 refilomod\core before copying the new files.

 UPDATING from 2.3.4 or older: the mod no longer loads through dxgi.dll. Delete
 the old dxgi.dll of this mod (keep any dxgi.dll from ReShade or Special K) and
 the old files in refilomod\core (core_001_001.dll, core_002_000.dll,
 core_002_002.dll) before
 copying the new files.

 UPDATING from 2.0.9.1 or older: replace winmm.dll and copy the refilomod
 folder. The settings file now lives in refilomod\ultrawide\ ; the old
 FFRS_UW.ini (and FFRS_UW.log) next to the exe are no longer used and can be
 deleted. Copy your own values into the new ini if you changed any.

 IMPORTANT: the game itself only lists 16:9 resolutions. If the Graphics
 page shows only 16:9 entries, the mod is usually still active; it adds your
 monitor's resolutions to the list as soon as the page is opened. Check the
 image in game, not the list. If you do not see ultrawide entries, set the
 Windows desktop to your native resolution first, and keep the game in
 Fullscreen.

STRUCTURE (refilomod)
 winmm.dll is a small loader. It loads the newest core from refilomod\core and
 the core loads every mod found in refilomod\<name>\. Other mods built on
 refilomod can be added later by copying their folder next to "ultrawide"
 without touching this mod. The shared log (if enabled) is refilomod\refilomod.log.

UNINSTALL
 Delete winmm.dll and the refilomod folder from that folder.

IN GAME
 F1  switches the mod on/off. Off = original game behaviour, 16:9 resolution
     list. After switching, re-enter the Graphics page and apply a resolution.
     The state is remembered for the next start.
 The hotkeys only react while the game window is in front.

 F2  opens the settings overlay: HUD layout (global and per element), world map,
     depth of field fix and strength, vignette fix, strength and shape. Changes
     apply at once and are saved to FFRS_UW.ini. While the overlay is open the
     mouse and keyboard do not reach the game (controller input does). Press F2
     again to close it. The overlay also lets you change the hotkeys for
     mod on/off, the vignette and the overlay itself (F1-F24, Pause, Insert,
     Home, End, ScrollLock). While a key is being set, no hotkey of the mod
     reacts, so the current key can be pressed again without switching anything.
     The keys can also be changed with ToggleKey, VignetteToggleKey and
     OverlayKey in the ini.

 F4  switches the vignette (dark screen edges) off/on, with the mod on or off.
     The mod starts with the vignette on.

 HUD settings ([Hud], [Field], [Battle]) and [Map] are re-read automatically
     when you save FFRS_UW.ini while the game is running, so you can place
     the elements and see the result at once. Other settings need a restart.
 The resolution list shows your monitor's resolutions (e.g. 5120x1440,
 3840x1080). Every entry is a 16:9 height with the width of your monitor's
 aspect ratio; only modes your monitor really supports are shown that way.

FFRS_UW.ini (in refilomod\ultrawide\, sections)
 [General]
  Enabled     1/0   mod on/off (also changed by the toggle key)
  ToggleKey   F1..F12, Pause, Insert, Home, End, ScrollLock, a letter or None
  Refocus     1/0   (default 1) brings the game window to the front if another
              program (e.g. an overlay) takes the focus right after the start.
              Only active in the first seconds; it stops as soon as the game
              has been in front once, so Alt+Tab is never blocked.
  Log         1/0   writes FFRS_UW.log (same folder as the ini) for troubleshooting
 [Hud]
  HudLayout   original (default) = HUD inside the centered 16:9 area,
              wide = HUD at the screen edges
 [Field]  (default = follow HudLayout, original or wide)
  FieldQuest      current quest, top left
  FieldMinimap    minimap, top right
  FieldRegion     region info, bottom left
  FieldChat       conversation window while walking in the overworld, left
  FieldChatNotice announcement that a conversation starts
 [Battle] (default = follow HudLayout, original or wide)
  BattleTurnOrder turn order, top left
  BattleEnemyInfo enemy info, left
  BattleCommands  command menu, top right
  BattleParty     character status, bottom right
 [Menu]
  MenuListMove 2 (default) = menus and headers are moved into the centred 16:9
              area directly in the game
  MenuListDX  0 = automatic shift width from your resolution (default)
  MenuHeaderPad 1/0 (default 1) menu headers move into the 16:9 area too
 [Map]
  MapLayout   wide (default) = world map is left untouched and uses the full
              width, original = world map inside the centred 16:9 area.
              Applied live while the map is open.
  MapBgMode   1/0   (default 1) background of the map menu only in the 16:9 area
 [Cutscene]
  CutsceneMode  pillarbox (default) = story cutscenes (intro, movie-like
              scenes) and the special scenes in battle (Resonance attacks, limit
              breaks, Esper summons and Esper attacks) are shown in 16:9 with
              black bars, stretch = they are stretched to the full width.
              In-game rendered scenes in the field stay ultrawide.
  CutsceneLiveScenes  wide (default) = limit breaks and Resonance attacks that
              are rendered live in the game (no movie file, e.g. Infinite Drive
              or Vision Resonance moves) stay in the full width, and the
              "Skip" hint sits at the right screen edge.
              pillarbox = they are shown in 16:9 like before.
              Real movies (e.g. Esper summons) always stay in 16:9.
 [Graphics]
  VignetteAspect  (default 5625) shape of the vignette on wide screens; 5625 = the
              16:9 shape stretched over the whole screen, 0 = game default
  VignetteToggleKey  F1..F12, a letter or None (default F4): vignette off/on
  DofFix      1/0   (default 1) depth of field (background blur) works on wide
              screens like in 16:9
  DofStrength percent (default 100 = same as 16:9, 30..400)
  VignetteStrength percent (default 100 = game default, 0 = no vignette,
              above 100 = darker edges, max 300). Applied live when you save
              the ini while the game is running.
 Optional keys that are not in the default ini: ReloadKey (F3, no longer
 needed), MenuPages. Keys from an old ini without sections are still
 read.

KNOWN LIMITATIONS
 - Scripted enemies in cutscene-like events may pop in at the old 16:9 edge.
 - Mouse hit testing is offset in the shifted menus (controller and keyboard
   are fine).
 - The Quests page still uses the full width.
 - The title screen: the copyright text is inside the 16:9 area, the
   "PipoEU" note at the top left stays at the screen edge.
 - The party display and the battle HUD with four characters were tested on
   32:9, 21:9 and 24:10. Other menu screens may still show
   small glitches; feedback with the ini option Log=1 is welcome.
 - Vision scenes (sanctuaries) stay in 16:9 for the whole scene. The tutorial
   image that follows the scene stays 16:9 until you dismiss it.
 - Movie cutscenes (e.g. the intro), Esper summons and every other battle
   scene that is a real movie stay in 16:9 exactly as long as the movie plays
   and return to ultrawide when it ends or is skipped. The key hint ("Skip")
   sits at the bottom right of the 16:9 area during these scenes. Live
   rendered limit break / Resonance scenes follow CutsceneLiveScenes (see
   above).
 - Shop: when you switch the mod with F1 while a tooltip is visible, the
   tooltip disappears for a moment and reappears at its new place.
 - Resonance selection menu in battle (the cross menu): fixed in 2.0.6 for
   BattleCommands=wide (the cross was placed too far to the right of its ring).
   Note: the ring itself is placed by the game when the menu opens. If you
   change BattleCommands (or other layout options in the ini) while the
   Resonance menu is open, the cross moves away from the ring until the next
   action in that menu. Change the ini entry before opening the menu.
 - Story cutscenes are detected through the game's event commands and the
   movie player. A cutscene that is not recognized is shown stretched
   (F1 switches the mod off if you want it undistorted), a recognized one
   returns to ultrawide when it ends. Set CutsceneMode=stretch to turn the
   detection off completely.
 - Developed and tested at 5120x1440, 3840x1080, 3440x1440 and 3456x1440. The mod
   finds its patch points by signature search; if a build is not recognized
   it simply does nothing.
 - Fullscreen at a 16:9 resolution on an ultrawide monitor is stretched by the
   monitor; use Windowed/Borderless for undistorted 16:9.

Works through a winmm.dll proxy; it only changes the game in memory. No game
files are modified.
