# Resident Evil 3 Remake Any Aspect Ratio

This mod adjusts the game's aspect ratio. It does not include an FOV adjustment.

## Installation

1. Extract the files from `Release-v1.0.0.zip` into the game folder containing `re3.exe`.
2. For Linux, SteamOS, or Android Winlator/Wine, set this environment variable for the game or container:

   - Name: `WINEDLLOVERRIDES`
   - Value: `dinput8=n,b`

## Aspect ratio

Edit `RE3_ARFix.ini` with a text editor:

```ini
[AspectRatio]
EnableARFix = true
AspectWidth = 4
AspectHeight = 3
```

Set `AspectWidth` and `AspectHeight` to the ratio you want, for example `16` and `9`. Set `EnableARFix` to `false` to disable the fix. This mod does not provide an FOV setting.

For handheld full-screen stretching, set the container resolution and display scaling in your game launcher to the desired values (for example, 1280x720 with Stretch scaling).

The bundled `dinput8.dll` is the Ultimate ASI Loader proxy DLL. Its MIT license is included in `Release-v1.0.0.zip` and in the repository root.
