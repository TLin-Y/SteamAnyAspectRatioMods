# Pentiment-Any-Aspect-Ratio

Aspect-ratio fix v0.1.0 for Pentiment 1.3.1842.

The fix bypasses the startup 16:9 resolution clamp and allows non-16:9 display modes in the resolution menu. Screen-output Cinemachine cameras preserve the original view width below 16:9 and the original view height at wider aspect ratios, without stretching. Book-page and snapshot render targets retain their original framing.

## Install

1. Extract `Pentiment-v0.1.0.zip` into the game folder containing `Pentiment.exe`.
2. On SteamOS / Proton, set the Steam launch option to:
   `WINEDLLOVERRIDES="winhttp=n,b" %command%`
3. On Winlator, add the environment variable `WINEDLLOVERRIDES` with value `winhttp=n,b`.

## Custom Aspect Ratio

Edit `Pentiment_ARFix.ini`. Positive dimensions request a windowed resolution on startup. The default is 1280x800 (16:10); set both dimensions to `0` to retain the game's resolution and fullscreen settings.

```ini
[AspectRatio]
Enabled = true

[Resolution]
Width = 1280
Height = 800
Borderless = true
```

Restart the game after editing the INI. Set `Enabled = false` to disable every hook.

The included INI sets `[Resolution] Borderless = true` to remove the title bar and resizable frame while retaining the window's client dimensions. This is a borderless window, not borderless fullscreen; it does not switch to the monitor's desktop resolution. With `0/0`, the flag removes decorations from the current game window without requesting a new resolution. Unity's resolution changes are still game-controlled, and the fix reapplies borderless styling if Unity recreates the frame. Restart with `Borderless = false` to restore normal window behavior. If the key is omitted, the fix keeps normal window decorations.

## Testing and Remove

Local 1280x960 (4:3) testing confirmed successful hook loading and a title screen filling the window without 16:9 bars. The user reported the game fixed with no other issues at this test resolution.

Borderless window testing passed for 1280x800, 1280x960, and 2560x720 client sizes, including repeated application and frame recreation. The local 1280x800 game run logged borderless activation, displayed no title bar, and was confirmed working by the user.

The camera-framing math tests pass at 4:3, 16:10, 16:9, 21:9, 32:9, and portrait ratios. A subsequent local run at 2560x720 logged a screen-camera aspect of 3.555556 and lens scale of 1.0, preserving height. Visual framing comparisons, including journal views and transitions, remain unverified. Additional visible areas may expose scene-art boundaries.

The fix checks the game build and instruction signatures before installing hooks. Check `Pentiment_ARFix.log` if it fails to load; unsupported updates are left unpatched.

To remove, close the game and remove `Pentiment_ARFix.asi`, `Pentiment_ARFix.ini`, and the supplied `winhttp.dll` loader. Do not remove a loader belonging to another mod. Original game binaries are not modified.

The camera framing math can be tested by compiling `Pentiment_ARFix.cpp` as a console application with `PENTIMENT_ARFIX_TEST` defined (C++20 or newer).
